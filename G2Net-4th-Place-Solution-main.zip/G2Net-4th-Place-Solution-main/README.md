# G2Net-4th-Place-Solution
4th place gold medal place solution representing team OGOGOG [Jarvislabs.ai]
