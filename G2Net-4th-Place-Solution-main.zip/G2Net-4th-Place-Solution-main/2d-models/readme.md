2D models training + inference code.
