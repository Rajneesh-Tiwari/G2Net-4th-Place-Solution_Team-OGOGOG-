1d cnn models along with training + inference scripts.
